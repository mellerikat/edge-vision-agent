{{/*
Expand the name of the chart.
*/}}
{{- define "edge-vision-agent.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "edge-vision-agent.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "edge-vision-agent.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "edge-vision-agent.labels" -}}
helm.sh/chart: {{ include "edge-vision-agent.chart" . }}
{{ include "edge-vision-agent.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "edge-vision-agent.selectorLabels" -}}
app.kubernetes.io/name: {{ include "edge-vision-agent.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "edge-vision-agent-inference.labels" -}}
helm.sh/chart: {{ include "edge-vision-agent.chart" . }}
{{ include "edge-vision-agent-inference.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "edge-vision-agent-inference.selectorLabels" -}}
app.kubernetes.io/name: {{ include "edge-vision-agent.name" . }}-inference
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "edge-vision-agent.serviceAccountName" -}}
{{- default (include "edge-vision-agent.fullname" .) .Values.serviceAccount.name }}
{{- end }}


{{/*
Define secret name
*/}}
{{- define "edge-vision-agent.secret.name" -}}
{{- if and .Values.secret .Values.secret.nameOverride }}
{{- .Values.secret.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-secret" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}


{{- define "edge-vision-agent.inference_manifest" }}
{{- tpl (.Files.Get .Values.inference.manifest) . }}
{{- end }}


{{/*
Define pv name
*/}}
{{- define "edge-vision-agent.pv.name" -}}
{{- if and .Values.pv .Values.pv.nameOverride }}
{{- .Values.pv.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "pv-%s" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}


{{/*
Define pvc name
*/}}
{{- define "edge-vision-agent.pvc.name" -}}
{{- if and .Values.pv .Values.pv.pvc .Values.pv.pvc.nameOverride }}
{{- .Values.pv.pvc.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "pvc-%s" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end}}