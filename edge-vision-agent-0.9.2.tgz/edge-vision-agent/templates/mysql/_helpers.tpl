{{/*
Define redis name
*/}}
{{- define "edge-vision-agent.mysql.name" -}}
{{- printf "%s-mysql" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/*
Common labels
*/}}
{{- define "edge-vision-agent.mysql.labels" -}}
helm.sh/chart: {{ include "edge-vision-agent.chart" . }}
{{ include "edge-vision-agent.mysql.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "edge-vision-agent.mysql.selectorLabels" -}}
app.kubernetes.io/name: {{ include "edge-vision-agent.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app: mysql
{{- end }}


{{/*
Create the name of the internal service to use
*/}}    
{{- define "edge-vision-agent.mysql.svc.internal.name" -}}
{{- printf "%s-mysql-internal" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}