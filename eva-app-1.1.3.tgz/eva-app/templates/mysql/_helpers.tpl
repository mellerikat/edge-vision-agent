{{/*
Define redis name
*/}}
{{- define "eva-app.mysql.name" -}}
{{- printf "%s-mysql" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/*
Common labels
*/}}
{{- define "eva-app.mysql.labels" -}}
helm.sh/chart: {{ include "eva-app.chart" . }}
{{ include "eva-app.mysql.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "eva-app.mysql.selectorLabels" -}}
app.kubernetes.io/name: {{ include "eva-app.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app: mysql
{{- end }}


{{/*
Create the name of the internal service to use
*/}}    
{{- define "eva-app.mysql.svc.internal.name" -}}
{{- printf "%s-mysql-internal" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}