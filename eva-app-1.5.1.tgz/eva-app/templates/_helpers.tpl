{{/*
Expand the name of the chart.
*/}}
{{- define "eva-app.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "eva-app.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "eva-app.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "eva-app.labels" -}}
helm.sh/chart: {{ include "eva-app.chart" . }}
{{ include "eva-app.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "eva-app.selectorLabels" -}}
app.kubernetes.io/name: {{ include "eva-app.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
component: eva-app
{{- end }}

{{/*
Common labels
*/}}
{{- define "eva-app-inference.labels" -}}
helm.sh/chart: {{ include "eva-app.chart" . }}
{{ include "eva-app-inference.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "eva-app-inference.selectorLabels" -}}
app.kubernetes.io/name: {{ include "eva-app.name" . }}-inference
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "eva-app.serviceAccount.name" -}}
{{- default (include "eva-app.fullname" .) .Values.serviceAccount.name }}
{{- end }}


{{/*
Define secret name
*/}}
{{- define "eva-app.secret.name" -}}
{{- if and .Values.secret .Values.secret.nameOverride }}
{{- .Values.secret.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-secret" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}


{{/*
Define pv name
*/}}
{{- define "eva-app.pv.name" -}}
{{- if and .Values.pv .Values.pv.nameOverride }}
{{- .Values.pv.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "pv-%s" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}


{{/*
Define pvc name
*/}}
{{- define "eva-app.pvc.name" -}}
{{- if and .Values.pvc .Values.pvc.nameOverride }}
{{- .Values.pvc.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "pvc-%s" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end}}


{{/*
Define inference manifest used by eva-app
*/}}
{{- define "eva-app.inference.manifest" }}
{{- tpl (.Files.Get .Values.inference.manifest) . }}
{{- end }}


{{/*
Define dockerconfigjson for ECR credentials
*/}}
{{- define "eva-app.regcred.dockerconfigjson" }}
{{- tpl (.Files.Get .Values.imagePullSecrets.dockerconfigjson) . }}
{{- end }}


{{/*
Define imagePullSecret name
*/}}
{{- define "eva-app.imagePullSecret.name" -}}
{{- if .Values.imagePullSecrets.nameOverride }}
{{- .Values.imagePullSecrets.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-secret-regcred" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Define regcred manifest
*/}}
{{- define "eva-app.regcred.regcred" }}
{{- tpl (.Files.Get .Values.imagePullSecrets.regcred) . }}
{{- end }}